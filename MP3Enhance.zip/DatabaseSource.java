import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class DatabaseSource implements Iterable<String>{
	
	private List<String> list = new ArrayList<String>();
	
	public DatabaseSource(){
		
			loadFromDatabase();
	}
	
	private void loadFromDatabase(){
		
		Connection connection = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Properties properties = new Properties();
			properties.load(new FileReader("database.properties"));
			System.out.println("url: "+properties.getProperty("url"));
			connection = DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"), properties.getProperty("password"));
			Statement statement = connection.createStatement();
			ResultSet results = statement.executeQuery("select * from playlist");
			while(results.next()){
				
				list.add(results.getString("name"));
			}
			
		} 
		catch (IOException | SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally{
			
			try {
				connection.close();
			} 
			catch (NullPointerException | SQLException e) {}
		}
	}

	@Override
	public Iterator<String> iterator() {
		
		return list.iterator();
	}
}

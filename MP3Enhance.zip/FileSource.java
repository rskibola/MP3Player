import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FileSource implements Iterable<String>{
	
	private List<String> list = new ArrayList<String>();
	
	public FileSource(String file){
		
		loadFromFile(file);
	}
	
	private void loadFromFile(String file) {
		
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			
			String line = br.readLine();
			while(line != null){
				
				list.add(line);
				line = br.readLine();
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				br.close();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public Iterator<String> iterator() {
		// TODO Auto-generated method stub
		return list.iterator();
	}

}

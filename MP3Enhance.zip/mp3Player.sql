create table playlist(
songID int not null auto_increment,
name varchar(15) not null,
primary key(songID),
unique(name)
);

insert into playlist (name) values ('AG.mp3');
insert into playlist (name) values ('BS.mp3');
insert into playlist (name) values ('EMR.mp3');
insert into playlist (name) values ('FLM.mp3');
insert into playlist (name) values ('HW.mp3');
insert into playlist (name) values ('PW.mp3');
insert into playlist (name) values ('SOYL.mp3');
insert into playlist (name) values ('TOM.mp3');
insert into playlist (name) values ('WN.mp3');